# ChatClient (C++/Linux)

## Libraries

JSON Parser Library: https://github.com/open-source-parsers/jsoncpp

## Compiling and Usage


```
ChatClient $ make
ChatClient $ ./client
ChatClient $ ./server
```
